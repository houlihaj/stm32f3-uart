.. _um:

User manual
===========

.. toctree::
    :maxdepth: 2

    how-it-works
    format-specifier
    instances
    thread-safety