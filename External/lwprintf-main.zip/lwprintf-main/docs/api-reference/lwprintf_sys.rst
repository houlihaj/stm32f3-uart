.. _api_lwprintf_sys:

System functions
================

System function are used in conjunction with thread safety.
Please check :ref:`thread_safety` section for more information

.. doxygengroup:: LWPRINTF_SYS