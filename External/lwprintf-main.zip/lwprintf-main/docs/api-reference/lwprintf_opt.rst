.. _api_lwprintf_opt:

Configuration
=============

This is the default configuration of the middleware.
When any of the settings shall be modified, it shall be done in dedicated application config ``lwprintf_opts.h`` file.

.. note::
	Check :ref:`getting_started` to create configuration file.

.. doxygengroup:: LWPRINTF_OPT
	:inner: