#!/usr/bin/env bash

cd lwprintf
mkdir build && cd build && cmake ../
make
