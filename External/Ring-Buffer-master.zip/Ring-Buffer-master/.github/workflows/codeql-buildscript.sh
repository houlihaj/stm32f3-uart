#!/usr/bin/env bash

cd examples
make
